

<?php $__env->startSection('title', 'HHS Panel administrador'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>HHS Panel Administrador</h1>
    <p>Editar rol</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Bienvenido al panel de administracion de Holy Sensations Spa </p>

    <?php if(session('info')): ?>
        <div class="alert alert-success">
            <strong>
                <?php echo e(session('info')); ?>

            </strong>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">
            <?php echo Form::model($role, ['route' => ['admin.roles.update', $role], 'method' => 'put']); ?>

            <?php echo $__env->make('admin.roles.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            <?php echo Form::submit('Actualizar role', ['class' => 'btn btn-warning']); ?>

            <?php echo Form::close(); ?>

        </div>
    </div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\HSS\resources\views/admin/roles/edit.blade.php ENDPATH**/ ?>