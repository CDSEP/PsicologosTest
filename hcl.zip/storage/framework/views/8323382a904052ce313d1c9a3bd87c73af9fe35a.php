

<?php $__env->startSection('title', 'HHS Panel administrador'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>HHS Panel Administrador</h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<p>Lista de usuarios</p>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.users-index')->html();
} elseif ($_instance->childHasBeenRendered('KqQcAzH')) {
    $componentId = $_instance->getRenderedChildComponentId('KqQcAzH');
    $componentTag = $_instance->getRenderedChildComponentTagName('KqQcAzH');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('KqQcAzH');
} else {
    $response = \Livewire\Livewire::mount('admin.users-index');
    $html = $response->html();
    $_instance->logRenderedChild('KqQcAzH', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\HSS\resources\views/admin/users/index.blade.php ENDPATH**/ ?>