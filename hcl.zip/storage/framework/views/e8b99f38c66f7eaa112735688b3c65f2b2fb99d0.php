

<?php $__env->startSection('title', 'EWAP Panel administrador'); ?>

<?php $__env->startSection('content_header'); ?>
    <a href="<?php echo e(route('admin.posts.create')); ?>" class="btn btn-success btn-sm float-right">Nuevo Post</a>

    <h1>EWAP Panel Administrador</h1>
    <p>Listado de clases</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php if(session('info')): ?>
        <div class="alert alert-success">
            <strong>
                <?php echo e(session('info')); ?>

            </strong>
        </div>
    <?php endif; ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.posts-index')->html();
} elseif ($_instance->childHasBeenRendered('tUxJ1XS')) {
    $componentId = $_instance->getRenderedChildComponentId('tUxJ1XS');
    $componentTag = $_instance->getRenderedChildComponentTagName('tUxJ1XS');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('tUxJ1XS');
} else {
    $response = \Livewire\Livewire::mount('admin.posts-index');
    $html = $response->html();
    $_instance->logRenderedChild('tUxJ1XS', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script>
        console.log('Hi!');
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\HCL\resources\views/admin/posts/index.blade.php ENDPATH**/ ?>