

<?php $__env->startSection('title', 'HHS Panel administrador'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>HHS Panel Administrador</h1>
    <a href="<?php echo e(route('admin.roles.create')); ?>" class="btn btn-success btn-sm float-right">Nuevo role</a>
    <p>Lista de roles</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Bienvenido al panel de administracion de Holy Sensations Spa </p>

    <?php if(session('info')): ?>
        <div class="alert alert-success">
            <strong>
                <?php echo e(session('info')); ?>

            </strong>
        </div>
    <?php endif; ?>


    <div class="card">
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Role</th>
                        <th colspan="2"></th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($role->id); ?></td>
                            <td><?php echo e($role->name); ?></td>
                            <td width=10px>
                                <a href="<?php echo e(route('admin.roles.edit', $role)); ?>" class="btn btn-primary btn-sm">Editar</a>
                            </td>
                            <td width=10px>
                                <form action="<?php echo e(route('admin.roles.destroy', $role)); ?>" method="POST">
                                    <?php echo method_field('DELETE'); ?>
                                    <?php echo csrf_field(); ?>
                                    <button type="submit" class="btn btn-danger btn-sm">Eliminar</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\HSS2\resources\views/admin/roles/index.blade.php ENDPATH**/ ?>