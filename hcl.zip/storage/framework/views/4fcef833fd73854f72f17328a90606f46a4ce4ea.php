<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="container py-8 bg-[#FFFFFF]">
        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <article class="w-full h-80 bg-cover bg-center rounded-md <?php if($loop->first): ?> md:col-span-2 <?php endif; ?>"
                    style="background-image: url( <?php if($post->image): ?> <?php echo e(Storage::url($post->image->url)); ?> <?php else: ?> https://i.ibb.co/1Tx1csW/11.png <?php endif; ?>)">

                    <div class="w-full h-full px-8 flex flex-col justify-center">
                        <div>
                            <?php $__currentLoopData = $post->tags; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <a href="<?php echo e(route('posts.tag', $tag)); ?>"
                                    class="inline-block px-3 h-6 bg-gray-600 text-white rounded-full">
                                    <?php echo e($tag->name); ?> </a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div> 
                        <h1 class="text-4xl text-white leading-8 font-bold mt-2">
                            <a href="<?php echo e(route('posts.show', $post)); ?>">
                                <?php echo e($post->name); ?>

                            </a>
                        </h1>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>



        </div>
        <div mt-4>
            <?php echo e($posts->links()); ?>

        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>

<?php /**PATH C:\laragon\www\HCL\resources\views/posts/index.blade.php ENDPATH**/ ?>