

<?php $__env->startSection('title', 'EWAP Panel administrador'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>EWAP Panel Administrador</h1>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<p>Lista de usuarios</p>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.users-index')->html();
} elseif ($_instance->childHasBeenRendered('a5Vm8Oc')) {
    $componentId = $_instance->getRenderedChildComponentId('a5Vm8Oc');
    $componentTag = $_instance->getRenderedChildComponentTagName('a5Vm8Oc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('a5Vm8Oc');
} else {
    $response = \Livewire\Livewire::mount('admin.users-index');
    $html = $response->html();
    $_instance->logRenderedChild('a5Vm8Oc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link rel="stylesheet" href="/css/admin_custom.css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script> console.log('Hi!'); </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\HCL\resources\views/admin/users/index.blade.php ENDPATH**/ ?>