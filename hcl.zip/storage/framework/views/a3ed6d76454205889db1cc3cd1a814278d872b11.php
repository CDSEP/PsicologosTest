

<?php $__env->startSection('title', 'EWAP Panel administrador'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>EWAP Panel Administrador</h1>
    <p>Crear nuevo rol</p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <p>Bienvenido al panel de administracion de EWAP </p>

    <?php if(session('info')): ?>
        <div class="alert alert-success">
            <strong>
                <?php echo e(session('info')); ?>

            </strong>
        </div>
    <?php endif; ?>

    <div class="card">
        <div class="card-body">

            <?php echo Form::open(['route' => 'admin.roles.store']); ?>


            <?php echo $__env->make('admin.roles.partials.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <?php echo Form::submit('Crear role', ['class' => 'btn btn-primary']); ?>

            <?php echo Form::close(); ?>


        </div>
    </div>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\HCL\resources\views/admin/roles/create.blade.php ENDPATH**/ ?>