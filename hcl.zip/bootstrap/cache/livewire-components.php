<?php return array (
  'admin.posts-index' => 'App\\Http\\Livewire\\Admin\\PostsIndex',
  'admin.users-index' => 'App\\Http\\Livewire\\Admin\\UsersIndex',
  'navigation' => 'App\\Http\\Livewire\\Navigation',
);