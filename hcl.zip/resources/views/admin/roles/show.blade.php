@extends('adminlte::page')

@section('title', 'EWAP Panel administrador')

@section('content_header')
    <h1>EWAP Panel Administrador</h1>
    <p>Mostrar rol</p>
@stop

@section('content')
    <p>Bienvenido al panel de administracion de EWAP </p>
@stop

@section('css')
    <link rel="stylesheet" href="/css/admin_custom.css">
@stop

@section('js')
    <script> console.log('Hi!'); </script>
@stop