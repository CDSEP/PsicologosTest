<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class UserControllerPdf extends Controller
{
    //
}
